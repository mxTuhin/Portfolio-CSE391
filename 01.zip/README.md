Portfolio Website with Pure HTML CSS for CSE 391 Assignments
<br>
<b>Version 1.00</b><br>
One Page Template<br>
Contains:<br>
Short Overview<br>
Personal Info<br>
Favourite Quote<br>
Fun Fact<br>
Important Links<br>
Favorite Movies<br>
Projects<br>
Page Information<br><br>
Web Page Live At: http://mxtuhin.ninja/cse391/assignment/01/
